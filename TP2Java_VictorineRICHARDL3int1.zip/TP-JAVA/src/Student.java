
public class Student {
    private String register_number;
    private double project_score;
    private double exam_score;
    private double lab_score;

    public Student (String register_number, double project_score, double exam_score, double lab_score){
        this.register_number = register_number;
        this.project_score = 0;
        this.exam_score = 0;
        this.lab_score = 0;
    }
}
